//
//  ViewController.swift
//  week2hw
//
//  Created by 이재용 on 4/11/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return productCellData.count + eventCellData.count + 1
        return productCellData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        switch indexPath.row {
//        case 0:
//            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
//            // Configure cell
//            return cell
//        case 1:
//            let cell = tableView.dequeueReusableCell(withIdentifier: "EventTableViewCell", for: indexPath) as! EventTableViewCell
//            // Configure cell
//            return cell
//        case 2:
//            let cell = tableView.dequeueReusableCell(withIdentifier: "CollectionContainerTableViewCell", for: indexPath) as! CollectionContainerViewCell
//            // Configure cell
//            return cell
//        default:
//            // Return a default cell or modify as necessary
//            return UITableViewCell()
//        }
    let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
            // 셀 구성 로직 추가
            return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130 // 적절한 높이 값으로 조정
    }
    
    
    
    //MARK: components
    //최상단 네비게이션 바
    
    let homeLabel = makeLabel(withText: "학익동")
    let menuButton = makeButton(withSystemName: "line.3.horizontal")
    let searchButton = makeButton(withSystemName: "magnifyingglass")
    let bellButton = makeButton(withSystemName: "bell")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setNavigationBar()
        setupTableView()
    }
    
    func setNavigationBar() {
        let leftItem = UIBarButtonItem (customView: homeLabel)
        navigationItem.leftBarButtonItem = leftItem
        
        let stackView = UIStackView(arrangedSubviews: [menuButton, searchButton, bellButton])
        stackView.axis = .horizontal
        stackView.spacing = 10
        stackView.distribution = .fillEqually
        
        let rightItem = UIBarButtonItem (customView: stackView)
        navigationItem.rightBarButtonItem = rightItem
        
    }
    //MARK: tableView Setting
    func setupTableView() {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 0),
            tableView.leftAnchor.constraint(equalTo: self.view.leftAnchor),
            tableView.rightAnchor.constraint(equalTo: self.view.rightAnchor),
            tableView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor)
        ])
        
        tableView.register(ProductTableViewCell.self, forCellReuseIdentifier: "ProductTableViewCell")
        tableView.register(EventTableViewCell.self, forCellReuseIdentifier: "EventTableViewCell")
        tableView.register(CollectionContainerViewCell.self, forCellReuseIdentifier: "CollectionContainerViewCell")
    }
}



extension ViewController {
    static func makeLabel(withText text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.textColor = .white
        return label
    }
    
    static func makeButton(withSystemName name: String) -> UIButton {
        let button = UIButton()
        button.setImage(UIImage(systemName: name), for: .normal)
        button.tintColor = .white
        return button
    }
    
}
